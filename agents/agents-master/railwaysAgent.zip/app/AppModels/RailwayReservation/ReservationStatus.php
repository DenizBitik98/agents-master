<?php


namespace App\AppModels\RailwayReservation;


class ReservationStatus
{
    const RESERVATION_NEW = 'new';
    const RESERVATION_CONFIRMING = 'confirming';
    const RESERVATION_CONFIRMED = 'confirmed';
    const RESERVATION_CONFIRM_ERROR = 'confirm_error';
    const RESERVATION_RETURNING = 'returning';
    const RESERVATION_RETURNED = 'returned';
    const RESERVATION_RETURN_ERROR = 'return_error';
}
