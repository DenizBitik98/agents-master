<?php


namespace App\Client\KTJ;


use GuzzleHttp\Client;

class DCTSClient extends Client
{

}
