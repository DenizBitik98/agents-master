<?php


namespace App\Common\Utils;


use App\Common\DayShift;

class DayShiftUtils
{
    static function getDayShiftChoices() {
        return [
            DayShift::MORNING=>'утро',
            DayShift::DAY=>'День',
            DayShift::EVENING=>'вечер',
            DayShift::NIGHT=>'ночь',
        ];
    }
}
