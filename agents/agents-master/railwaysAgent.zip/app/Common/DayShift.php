<?php


namespace App\Common;


class DayShift
{
    public const MORNING = 'morning';
    public const DAY = 'day';
    public const EVENING = 'evening';
    public const NIGHT = 'night';
}
