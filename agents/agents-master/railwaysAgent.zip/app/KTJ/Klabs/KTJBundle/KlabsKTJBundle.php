<?php

namespace App\KTJ\Klabs\KTJBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KlabsKTJBundle extends Bundle
{
}
