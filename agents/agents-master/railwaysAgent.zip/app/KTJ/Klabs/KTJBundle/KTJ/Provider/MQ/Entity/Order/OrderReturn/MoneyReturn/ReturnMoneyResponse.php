<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\MoneyReturn;

use App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\ReturnTickets\ReturnTicketsResponse;

/**
 * Class ReturnMoneyResponse
 * @package Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\MoneyReturn
 */
class ReturnMoneyResponse extends ReturnTicketsResponse
{

}
