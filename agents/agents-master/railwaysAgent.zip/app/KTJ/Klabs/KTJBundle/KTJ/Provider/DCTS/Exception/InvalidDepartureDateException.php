<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception;

/**
 * Class InvalidDepartureDateException
 * @package Klabs\KTJBundle\KTJ\Provider\DCTS\Exception
 */
class InvalidDepartureDateException extends DefaultException
{

}
