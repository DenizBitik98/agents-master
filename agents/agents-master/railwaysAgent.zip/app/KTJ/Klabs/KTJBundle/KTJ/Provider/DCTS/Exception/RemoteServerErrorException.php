<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 07.08.2018
 * Time: 15:28
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception;
/**
 * Class RemoteServerErrorException
 * @package Klabs\KTJBundle\KTJ\Provider\DCTS\Exception
 */
class RemoteServerErrorException extends DefaultException {

}
