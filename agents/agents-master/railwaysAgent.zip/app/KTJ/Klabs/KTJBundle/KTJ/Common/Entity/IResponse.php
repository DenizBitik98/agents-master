<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 27.05.2018
 * Time: 15:39
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Common\Entity;
/**
 * Interface IResponse
 * @package Klabs\KTJBundle\KTJ\Common\Entity
 */
interface IResponse {

}
