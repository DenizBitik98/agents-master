<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 02.10.2018
 * Time: 14:36
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Entity\Report\ReturnController\Apply\Fail;

use App\KTJ\Klabs\KTJBundle\KTJ\Common\Entity\IResponse;

/**
 * Class ApplyFailResponse
 * @package Klabs\KTJBundle\KTJ\Entity\Report\ReturnController\Apply\Fail
 */
class ApplyFailResponse implements IResponse {

}
