<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 31.05.2018
 * Time: 7:19
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception;
/**
 * Class Ex2014Exception
 * @package Klabs\KTJBundle\KTJ\Provider\DCTS\Exception
 */
class Ex2014Exception extends DefaultException {
	protected $message = '1092014: 2014-В указанную дату поезд не ходит.';
}
