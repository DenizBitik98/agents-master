<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\MoneyReturn;


/**
 * Class ReturnMoneyRequest
 * @package Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\MoneyReturn
 */
class ReturnMoneyRequest extends MoneyReturnReferenceRequest
{

}
