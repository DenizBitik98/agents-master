<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\ReturnTickets;

use App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\ReturnInfo\ReturnReferenceRequest;

/**
 * Class ReturnTicketsRequest
 * @package Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\ReturnTickets
 */
class ReturnTicketsRequest extends ReturnReferenceRequest
{

}
