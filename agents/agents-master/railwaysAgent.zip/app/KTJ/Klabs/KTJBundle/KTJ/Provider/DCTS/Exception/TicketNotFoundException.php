<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 31.05.2018
 * Time: 7:05
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception;
/**
 * Class TicketNotFoundException
 * @package Klabs\KTJBundle\KTJ\Provider\DCTS\Exception
 */
class TicketNotFoundException extends DefaultException {

}
