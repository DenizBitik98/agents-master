<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\MoneyReturn;

use App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\ReturnInfo\ReturnReferenceResponse;

/**
 * Class MoneyReturnReferenceResponse
 * @package Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\OrderReturn\MoneyReturn
 */
class MoneyReturnReferenceResponse extends ReturnReferenceResponse
{

}
