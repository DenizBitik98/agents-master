<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 24.05.2018
 * Time: 12:49
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Common\Entity;
/**
 * Interface IQuery
 * @package Klabs\KTJBundle\KTJ\Common\Entity
 */
interface IRequest {
}
