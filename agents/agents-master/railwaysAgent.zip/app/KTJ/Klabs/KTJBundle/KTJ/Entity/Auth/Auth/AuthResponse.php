<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 01.10.2018
 * Time: 16:32
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Entity\Auth\Auth;

use App\KTJ\Klabs\KTJBundle\KTJ\Common\Entity\IResponse;

/**
 * Class AuthResponse
 * @package Klabs\KTJBundle\KTJ\Entity\Auth\Auth
 */
class AuthResponse implements IResponse {

}
