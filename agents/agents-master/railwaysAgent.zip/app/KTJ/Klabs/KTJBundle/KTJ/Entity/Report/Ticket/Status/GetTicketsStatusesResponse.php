<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 01.08.2018
 * Time: 16:26
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Entity\Report\Ticket\Status;

use App\KTJ\Klabs\KTJBundle\KTJ\Common\Entity\IResponse;

/**
 * Class GetTicketsStatusesResponse
 * @package Klabs\KTJBundle\KTJ\Entity\Report\Ticket\Status
 */
class GetTicketsStatusesResponse implements IResponse {
	//@TODO: Response properties
}
