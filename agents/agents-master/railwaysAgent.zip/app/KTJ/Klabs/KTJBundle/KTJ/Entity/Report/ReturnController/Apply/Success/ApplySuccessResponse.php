<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 02.10.2018
 * Time: 14:36
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Entity\Report\ReturnController\Apply\Success;

use App\KTJ\Klabs\KTJBundle\KTJ\Common\Entity\IResponse;

/**
 * Class ApplySuccessResponse
 * @package Klabs\KTJBundle\KTJ\Entity\Report\ReturnController\Apply\Success
 */
class ApplySuccessResponse implements IResponse {

}
