<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Exception;

use Exception;

/**
 * Class MethodNotImplementedException
 * @package Klabs\KTJBundle\KTJ\Exception
 */
class MethodNotImplementedException extends Exception
{

}
