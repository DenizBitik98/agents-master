<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\ExpressCommit\Commit;


use App\KTJ\Klabs\KTJBundle\KTJ\Common\Entity\IResponse;

/**
 * Class Response
 * @package Klabs\KTJBundle\KTJ\Provider\MQ\Entity\ExpressCommit\Commit
 */
class Response implements IResponse
{

}
