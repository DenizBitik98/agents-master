<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 31.05.2018
 * Time: 7:04
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception;
/**
 * Class InvalidSignatureException
 * @package Klabs\KTJBundle\KTJ\Provider\DCTS\Exception
 */
class InvalidSignatureException extends DefaultException {

}
