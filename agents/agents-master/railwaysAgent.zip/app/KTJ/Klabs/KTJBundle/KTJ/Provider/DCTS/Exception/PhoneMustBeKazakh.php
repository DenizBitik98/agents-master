<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 28.08.2018
 * Time: 14:58
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception;
/**
 * Class PhoneMustBeKazakh
 * @package Klabs\KTJBundle\KTJ\Provider\DCTS\Exception
 */
class PhoneMustBeKazakh extends DefaultException {

}
