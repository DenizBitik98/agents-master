<?php


namespace App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\Common\Identity;


class ByBlankIdentityWithSeries
{

}
