<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 02.08.2018
 * Time: 12:57
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Common\Controller;

use App\KTJ\Klabs\KTJBundle\KTJ\Aware\IProviderAware\IProviderAware;

/**
 * Interface IController
 * @package Klabs\KTJBundle\KTJ\Common\Controller
 */
interface IController extends IProviderAware {

}
