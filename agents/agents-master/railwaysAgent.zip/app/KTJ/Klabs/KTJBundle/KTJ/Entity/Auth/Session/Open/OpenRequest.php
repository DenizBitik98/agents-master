<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 01.10.2018
 * Time: 16:35
 */

namespace App\KTJ\Klabs\KTJBundle\KTJ\Entity\Auth\Session\Open;
class OpenRequest {

}
