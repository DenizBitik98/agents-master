<?php
/**
 * Created by PhpStorm.
 * User: Urmat
 * Date: 23.05.2018
 * Time: 16:58
 */

namespace App\KTJ\Klabs\KTJBundle\IdP\Client\DefaultClient\Event;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class IdPCallBeforeEvent
 * @package Klabs\KTJBundle\IdP\Client\DefaultClient\Event
 */
class IdPCallBeforeEvent extends Event {
}
