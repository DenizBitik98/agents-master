<?php

namespace App\Http\Controllers;

use App\Common\Utils\DayShiftUtils;
use App\Models\SaleRailwayCarType;
use App\Models\SaleRailwayTicket;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\View\View;
use Knp\Snappy\Image;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class TicketController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function html(Request $request): View
    {
        $ticketId = $request->get('ticketId');

        $ticket = $this->findTicket($ticketId);

        /*if(!$this->isGranted('ROLE_ADMIN')){
            $this->denyAccessUnlessGranted(RailwayTicketVoter::DOWNLOAD, $ticket);
        }*/


        return view('railway.ticket.html', [
            'ticket'=>$ticket,
            'contactPhones'=>''

        ]);
    }

    public function image(Request $request/*, Image $knpSnappyImage*/): View
    {
        $ticketId = $request->get('ticketId');

        $ticket = $this->findTicket($ticketId);

        /*if(!$this->isGranted('ROLE_ADMIN')){
            $this->denyAccessUnlessGranted(RailwayTicketVoter::DOWNLOAD, $ticket);
        }*/

        $html = $this->renderView('railway.ticket.html', [
            'ticket'        => $ticket,
            'contactPhones' => ''//$this->getParameter('ticket.contact phones')
        ]);

        $snappy = App::make('ticket.pdf');

        return new Response(
            $snappy->getOutputFromHtml($html),
            200,
            array(
                'Content-Type'          => 'application/pdf',
                'Content-Disposition'   => 'attachment; filename="file.pdf"'
            )
        );
    }

    protected function findTicket($ticketId) {


        $ticket = SaleRailwayTicket::find('KlabsSaleRailwayBundle:Ticket', $ticketId);

        if (null === $ticket) {
            throw new NotFoundHttpException('Ticket not found');
        }

        return $ticket;
    }

}
