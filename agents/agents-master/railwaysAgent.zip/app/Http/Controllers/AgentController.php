<?php

namespace App\Http\Controllers;

use App\Models\Agent;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

/**
 * Class AgentController
 * @package App\Http\Controllers
 */
class AgentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function list(): View
    {
        return view('agents.list', [
            'agents' => Agent::all()
        ]);
    }

    public function create($id=0): View
    {

        $agent = new Agent();

        if($id > 0){
            $agent = Agent::find($id);
        }

        return view('agents.create', [
            'agent' => $agent
        ]);
    }

    /**
     * @param int $id
     * @return View
     */
    public function edit(Request $request): View
    {

        $agent = new Agent();

        if($request->get('id') > 0){
            $agent = Agent::find($request->get('id'));
        }


        return view('agents.edit', [
            'agent' => $agent
        ]);
    }


    public function store(Request $request)
    {

        /*$this->validate($request, [
            'title' => 'required|max:255',
            'contents' => 'required',
        ]);*/
        /*$request->validate([
         'name' => 'required',
         'email' => 'required|email|unique:users',
         'password' => 'required|min:6',
     ]);*/

        /*$data = $request->all();*/


        $agent = new Agent();
        $user = new User();

        $id = $request->get('id');

        if($id > 0){
            $agent = Agent::find($id);
            $user = $agent->getUser();
        }



        $agent->name = $request->input('name');
        $agent->company_name = $request->input('companyName');
        $agent->phone_number = $request->input('phoneNumber');
        $agent->address = $request->input('address');
        $agent->commission = $request->input('commission');
        $agent->current_balance = 0;

        $agent->save();

        $user->name = $request->input('username');
        $user->email = $request->input('email');
        $user->password = Hash::make($request->input('password'));
        $user->agent_id = $agent->id;
        $user->role = 'ROLE_AGENT';

        $user->save();




        return redirect('agents');
    }

    public function agentInfo(Request $request){

        return view('agents.edit', [
            'agent' => $agent
        ]);
    }

}
