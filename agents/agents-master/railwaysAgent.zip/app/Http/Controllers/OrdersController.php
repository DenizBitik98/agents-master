<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use App\Models\SaleRailwayStation;
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function railwayOrders(Request $request)
    {
        $orders = Reservation::all();

        return view('orders.railway.ordersList', [
            'orders'=>$orders
        ]);
    }
}
