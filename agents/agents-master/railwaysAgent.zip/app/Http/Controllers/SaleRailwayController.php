<?php

namespace App\Http\Controllers;

use App\AppModels\RailwayReservation\ReservationStatus;
use App\Common\Utils\DayShiftUtils;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Order\Reserve\Passenger;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Order\Reserve\ReserveResponse;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Order\Reserve\Ticket;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Search\Seat\CarSearchRequest;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Search\Seat\DepDate;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Search\Seat\Direction;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Search\Seat\Train;
use App\Models\Agent;
use App\Models\Reservation;
use App\Models\SaleRailwayCarType;
use App\Models\SaleRailwayDocument;
use App\Models\SaleRailwayPassenger;
use App\Models\SaleRailwayReservation;
use App\Models\SaleRailwayStation;
use App\Models\SaleRailwayTicket;
use App\Services\KTJ\KTJService;
use App\Services\Utils\BalanceUtils;
use App\Services\Utils\Railway\ReservationUtils;
use App\Services\Utils\Utils;
use App\ViewModels\Sale\Railway\Buy\BlankForm;
use App\ViewModels\Sale\Railway\Buy\BuyForm;
use App\ViewModels\Sale\Railway\Train\SearchModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;;

class SaleRailwayController extends Controller
{
    /**
     * @var null |  KtjService
     */
    protected $ktjService = null;
    /**
     * @var null | Utils
     */
    protected $utils = null;
    /**
     * @var null | BalanceUtils
     */
    protected $balanceUtils = null;
    /**
     * @var null | ReservationUtils
     */
    protected $reservationUtils = null;

    public function __construct(KtjService $ktjService, BalanceUtils $balanceUtils, ReservationUtils $reservationUtils){
        $this->utils = new Utils();

        $this->ktjService = $ktjService;
        $this->balanceUtils = $balanceUtils;
        $this->reservationUtils = $reservationUtils;

        $this->middleware('auth');
    }

    public function searchStation(Request $request)
    {
        $stations = SaleRailwayStation::where('station_name_full', 'LIKE', '%'.mb_strtoupper($request->get('query')).'%')
            ->get();

        $stData = [];

        foreach ($stations as $station){
            $stData[] = [
                'value'=>$station->station_name_full,
                'data'=>$station->station_code,
            ];
        }

        return  response()->json(['suggestions'=>$stData]);
    }

    public function searchTrain(): View
    {
        $dayShifts = DayShiftUtils::getDayShiftChoices();
        $carTypes = SaleRailwayCarType::all();

        $ktjResponse = null;

        return view('railway.searchForm', [
            'dayShifts'=>$dayShifts,
            'carTypes'=>$carTypes,
            'ktjResponse'=>$ktjResponse,

        ]);
    }



    public function searchTrainResult(Request $request): View
    {

        $searchModel = new SearchModel();
        $searchModel->setDepartureStationCode($request->input('departureStationCode'));
        $searchModel->setArrivalStationCode($request->input('arrivalStationCode'));
        $searchModel->setDepartureDate($request->date('departureDate'));

        $searchRequest = $this->utils->buildRouteSearchRequest($searchModel);

        $ktjResponse = $this->ktjService->getSearchPlacesService()->searchAuthorized($searchRequest);





        $dayShifts = DayShiftUtils::getDayShiftChoices();
        $carTypes = SaleRailwayCarType::all();

        return view('railway.searchForm', [
            'dayShifts'=>$dayShifts,
            'carTypes'=>$carTypes,
            'ktjResponse'=>$ktjResponse
        ]);
    }

    public function searchCarsResult(Request $request): View
    {


        //var_dump($request->date("carSearch.forwardDirection.depDate"));exit;



        $carSearchRequest = new CarSearchRequest();
        $carSearchRequest->setStationFrom($request->input("carSearch.stationFrom"));
        $carSearchRequest->setStationTo($request->input("carSearch.stationTo"));

        $direction = new Direction();
        $direction->setType(Direction::TYPE_FORWARD);
        $direction->setDepDate(new DepDate($request->date("carSearch.forwardDirection.depDate")));
        $direction->setDepTime($request->date("carSearch.forwardDirection.depDate"));
        $direction->setTrain(new Train($request->input("carSearch.forwardDirection.train")));

        $carSearchRequest->setForwardDirection($direction);

        $ktjResponse = $this->ktjService->getSearchPlacesService()->searchCarsAuthorized($carSearchRequest);

        $this->utils->filterSimilarCar($ktjResponse);




        $dayShifts = DayShiftUtils::getDayShiftChoices();
        $carTypes = SaleRailwayCarType::all();

        return view('railway.searchCarsResult', [
            'dayShifts'=>$dayShifts,
            'carTypes'=>$carTypes,
            'ktjResponse'=>$ktjResponse
        ]);
    }

    public function buy(Request $request): View
    {
        //var_dump($request->get('buy_form_contract'));exit;

        $buyForm = new BuyForm();

        $order = new Reservation();

        $byRequest = $this->utils->buildReserveRequest($buyForm->getForwardDirection(), $buyForm->getBlanks());

        $ktjResponse = $this->ktjService->getETicketService()->reservationReserveAuthorized($byRequest);

        $dbReservationForward = $this->createDbReservation($ktjResponse);

        $order->addRailwayReservation($dbReservationForward);
        if($buyForm->getForwardDirection() != null){
            $byRequest = $this->utils->buildReserveRequest($buyForm->getBackwardDirection(), $buyForm->getBlanks());

            $ktjResponse = $this->ktjService->getETicketService()->reservationReserveAuthorized($byRequest);

            $dbReservationBackward = $this->createDbReservation($ktjResponse);

            $order->addRailwayReservation($dbReservationBackward);
        }



        DB::beginTransaction(); //Start transaction!

        try{

            $order->save();
            /**@var SaleRailwayReservation $reservation*/
            foreach ($order->getRailwayReservations() as $reservation){
                $reservation->reservation_id = $order->id;

                $reservation->save();
                /**@var SaleRailwayTicket $ticket*/
                foreach ($reservation->getTickets() as $ticket){
                    $ticket->reservation_id = $reservation->id;

                    $ticket->save();

                    /**@var SaleRailwayPassenger $passenger*/
                    foreach ($ticket->getPassengers() as $passenger){
                        $passenger->ticket_id = $ticket->id;

                        $passenger->save();
                    }
                }
            }

            DB::commit();
        }
        catch(\Exception $e)
        {
            //failed logic here
            DB::rollback();

        }


/*        $dayShifts = DayShiftUtils::getDayShiftChoices();*/
        $docTypes = SaleRailwayDocument::all();

        $blanks = [];
        $blanks[] = new BlankForm();


        return view('railway.buy', [
            'blanks'=>$blanks,
            'docTypes'=>$docTypes
            /*'dayShifts'=>$dayShifts,
            'carTypes'=>$carTypes,*/
            //'ktjResponse'=>$ktjResponse
        ]);
    }

    public function confirm(Request $request){
        $reservationId = $request->get('reservationId', false);

        /**
         * @var $reservation Reservation
         */
        if($reservationId != false && ($reservation = Reservation::find($reservationId)) instanceof Reservation){
            //$this->denyAccessUnlessGranted(RailwayTicketVoter::ACCESS_OWN_RESERVATION, $reservation);

            if($reservation->isPayed()){
                return view('railway.pay.payed', []);
            }
        }


        if($request->isMethod(Request::METHOD_POST)){
            $bayResult = $this->reservationUtils->buy($reservation, $this->getAgent());

            if($bayResult){
                /**
                 * @var SaleRailwayReservation $rr
                 */
                foreach ($reservation->getRailwayReservationsRelations() as $rr) {
                    $rr->is_available_for_confirm = true;
                    //$rr->setOrderStatus(ReservationStatus::RESERVATION_CONFIRMING);
                    $rr->save();
                }
            }
        }

        return view('railway.pay.confirm', [
            '$reservation'=>$reservation
        ]);
    }

    /**
     * @return Agent
     */
    protected function getAgent(){
        return new Agent();
    }


    /**
     * @param ReserveResponse $reservation
     * @return SaleRailwayReservation
     */
    protected function createDbReservation(ReserveResponse $reservation){

        $dbReservation = new SaleRailwayReservation();
        $dbReservation->api_id = $reservation->getOrder()->getId();
        $dbReservation->express_id = $reservation->getOrder()->getExpressID();
        $dbReservation->departure_station = $reservation->getDeparture()->getStationCode();
        $dbReservation->departure_time = $reservation->getDeparture()->getDate();
        $dbReservation->arrival_station = $reservation->getArrival()->getStationCode();
        $dbReservation->arrival_time = $reservation->getArrival()->getDate();
        $dbReservation->iidb = $reservation->getIIDB();
        $dbReservation->reserved_at = $reservation->getOrder()->getCreateDate();
        $dbReservation->payment_type = $reservation->getOrder()->getPaymentType();
        $dbReservation->departure_train = $reservation->getDeparture()->getTrain();
        $dbReservation->arrivalTrain = $reservation->getArrival()->getTrain();
        $dbReservation->is_talgo = $reservation->getDeparture()->getisTalgoTrain();
        $dbReservation->car = $reservation->getCar()->getNumber();
        $dbReservation->car_type = $reservation->getCar()->getType();
        $dbReservation->carrier = $reservation->getCarrier()->getName();
        $dbReservation->bin = $reservation->getPayerInfo()->getBin();
        $dbReservation->nds = $reservation->getCarrier()->getInn();
        $dbReservation->service_class = $reservation->getCar()->getClassService();
        $dbReservation->sign_gb = $reservation->getSignGb();
        $dbReservation->carrier_name = $reservation->getCarrier()->getName();
        $dbReservation->carrier_inn = $reservation->getCarrier()->getInn();
        $dbReservation->car_carrier_name = $reservation->getCar()->getCarrierName();
        $dbReservation->payer_info_name = $reservation->getPayerInfo()->getName();
        $dbReservation->payer_info_bin = $reservation->getPayerInfo()->getBin();
        $dbReservation->payer_info_is_agent = $reservation->getPayerInfo()->getisAgent();
        $dbReservation->payer_info_is_vat_charged = $reservation->getPayerInfo()->getisVATCharged();
        $dbReservation->terminal_name = $reservation->getTerminalName();
        $dbReservation->terminal_znkkm = $reservation->getTerminalZNKKM();
        $dbReservation->departure_time_zone = $reservation->getDeparture()->getTimezone();
        $dbReservation->arrival_time_zone = $reservation->getArrival()->getTimezone();

        foreach ($reservation->getTickets() as $ticket ){
            $dbReservation->addTicket();
        }

        return $dbReservation;

    }

    /**
     * @param Ticket $ticket
     * @return SaleRailwayTicket
     */
    protected function createDbTicket(Ticket $ticket){
        $dbTicket = new SaleRailwayTicket();
        $dbTicket->ticket_id = $ticket->getTicketId();
        $dbTicket->express_id = $ticket->getExpressID();
        $dbTicket->cost = $ticket->getTariffPaymentTotal();
        $dbTicket->asasasas = $ticket->getNoBedding();
        $dbTicket->seats = $ticket->getSeats()->toArray();
        $dbTicket->tariff = $ticket->getTariff();
        $dbTicket->tariff_b = $ticket->getTariffB();
        $dbTicket->tariff_p = $ticket->getTariffP();
        $dbTicket->tariff_service = $ticket->getTariffService();
        $dbTicket->tariff_nds = $ticket->getTariffNDS();
        $dbTicket->tariff_nds_service = $ticket->getTariffServiceNDS();
        $dbTicket->tariff_dealer = $ticket->getTariffDealer();
        $dbTicket->tariff_pwithout_service = $ticket->getTariffPWithoutService();
        $dbTicket->tariff_total = $ticket->getTariffTotal();
        $dbTicket->nds_certificate = $ticket->getPayerInfo()->getNDSCertificate()();
        $dbTicket->discount = $ticket->getDiscountCard();
        $dbTicket->tariff_type = $ticket->getTariffType();
        $dbTicket->car_air_conditioning = $ticket->getCarAirConditioning();
        $dbTicket->eco_friendly_toilets = $ticket->getEcoFriendlyToilets();


        foreach ( $ticket->getPassengers() as $passenger )
        {
            /** @var SaleRailwayPassenger $mdlPassenger */
            $mdlPassenger = new SaleRailwayPassenger();
            $mdlPassenger->name = $passenger->getName();
            $mdlPassenger->document = $passenger->getDoc();
            $mdlPassenger->citizenship = $passenger->getCitizenship();
            $mdlPassenger->birthday = $passenger->getBirthday();
            $mdlPassenger->sex = $passenger->getSex();

            $dbTicket->addPassenger($mdlPassenger);
        }

        return $dbTicket;
    }

}
