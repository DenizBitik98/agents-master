<?php

namespace App\Console\Commands;

use App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception\InvalidOrderInfoException;
use App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception\InvalidOrderStatusException;
use App\KTJ\Klabs\KTJBundle\KTJ\Provider\DCTS\Exception\OrderCanceledException;
use App\KTJ\Klabs\KTJBundle\KTJ\Provider\MQ\Entity\Order\Confirm\Response;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Order\Confirm\Ticket as KTJTicket;
use App\KTJ\Klabs\KTJBundle\KTJ\Entity\Common\PaymentInfo as KTJPaymentInfo;
use App\Models\Reservation;
use App\Models\SaleRailwayReservation;
use App\Models\SaleRailwayTicket;
use App\Services\KTJ\KTJService;
use GuzzleHttp\Exception\TransferException;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RailwayReservationConfirm extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'railway:confirm:reservation';
    /**
     * @var null |  KtjService
     */
    protected $ktjService = null;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(KTJService $ktjService)
    {
        parent::__construct();

        $this->ktjService = $ktjService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        DB::beginTransaction();

        try{
            $reservations = $this->findUnconfirmedReservations();
            foreach ($reservations as $reservation) {
                try {
                    $ktjConfirmResponse = $this->confirmReservation($reservation);
                    $this->setReservationAsConfirmed($reservation, $ktjConfirmResponse);
                } catch (InvalidOrderInfoException $exception) {
                    $this->removeReservationFromConfirm($reservation);
                } catch (TransferException $transferException) {
                    continue;
                } catch (InvalidOrderStatusException $exception) {
                    $this->removeReservationFromConfirm($reservation);
                }catch (OrderCanceledException $exception) {
                    $this->removeReservationFromConfirm($reservation);
                }
            }


            DB::commit();
        }catch (\Exception $e){
            DB::rollBack();
        }




        return 0;
    }


    protected function setReservationAsConfirmed(SaleRailwayReservation $railwayReservation, Response $confirmResponse): ?SaleRailwayReservation
    {
        $railwayReservation->is_confirmed = true;
        $railwayReservation->is_available_for_confirm = false;
        //$railwayReservation->setOrderStatus(ReservationStatus::RESERVATION_CONFIRMED);
        $ktjTikets = $confirmResponse->getTickets();

        /** @var KTJTicket $ktjTiket */
        foreach ($ktjTikets as $ktjTiket) {

            /** @var SaleRailwayTicket $ticket */
            $ticket = SaleRailwayTicket::where(
                'express_id', '=', $ktjTiket->getTicketId()
             )->first();

            $ticket->el_reg_status = $ktjTiket->getElRegStatus();
            $ticket->stop_date = $ktjTiket->getStopDateTime();

            $ticket->barcode = $ktjTiket->getPaymentInfo()->getBarcodeText();
            $ticket->payment_number = $ktjTiket->getPaymentInfo()->getPaymentNumber();
            $ticket->fiscal_number = $ktjTiket->getPaymentInfo()->getFiscalNumber();
            $ticket->payment_info_rnm = $ktjTiket->getPaymentInfo()->getRNM();
            $ticket->el_reg_status = $ktjTiket->getElRegStatus();
            $ticket->stop_date = $ktjTiket->getStopDateTime();

            ///ofd
            $ticket->fiscal_document_number = $ktjTiket->getPaymentInfo()->getFiscalDocumentNumber();
            $ticket->fiscalizator_type = $ktjTiket->getPaymentInfo()->getFiscalizatorType();
            $ticket->fiscal_date = $ktjTiket->getPaymentInfo()->getFiscalDate();
            $ticket->qr_code = $ktjTiket->getPaymentInfo()->getQrCode();


            $ticket->save();
        }

        //$this->sendMail($railwayReservation);
        return $railwayReservation;
    }

    protected function removeReservationFromConfirm(SaleRailwayReservation $railwayReservation): ?SaleRailwayReservation
    {
        $railwayReservation->is_confirmed = false;
        $railwayReservation->is_available_for_confirm = false;
        //$railwayReservation->setOrderStatus(ReservationStatus::RESERVATION_CONFIRM_ERROR);
        $railwayReservation->save();

        return $railwayReservation;
    }


    protected function findUnconfirmedReservations(){
        return SaleRailwayReservation::where('is_confirmed', '=', false)->where('is_available_for_confirm', '=', true)->get();
    }
}
